package model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class MovieDao {
	public void create(Movie movie)
	{
		Session session = ConnectionFactory.getConnection();
		Transaction tran = session.beginTransaction();
//		session.persist(movie);
//		using save method to create a record 
		Serializable id=session.save(movie);
		System.out.println("Movie added to the db,and its id is:"+id);
		tran.commit();
		session.close();
	}
	public List<Movie> read()
	{
		Session session=ConnectionFactory.getConnection();
		return session.createCriteria(Movie.class).list()
;		
		
	}
	public Movie read(Integer id)
	{
		Session session=ConnectionFactory.getConnection();
		return (Movie) session.get(Movie.class, id);
	}
	public void update(Movie arg)
	{
		Session session=ConnectionFactory.getConnection();
		Transaction tran=session.beginTransaction();
		Movie old=(Movie)session.get(Movie.class, arg.getId());
		if(old==null)
		{
			return;
		}
		old.setName(arg.getName());
		old.setReleaseDate(arg.getReleaseDate());
		session.persist(old);
		tran.commit();
		session.close();
	}
	public void delete(Integer id)
	{
		
		Session session=ConnectionFactory.getConnection();
		Movie movie =(Movie) session.get(Movie.class, id);
		Transaction tran=session.beginTransaction();
		
		
		session.delete(movie);
		tran.commit();
		session.close();
	}

	
	
}
