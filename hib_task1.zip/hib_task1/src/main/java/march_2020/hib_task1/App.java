package march_2020.hib_task1;

import java.util.Date;
import java.util.List;

import model.Movie;
import model.MovieDao;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//        System.out.println( "Hello World!" );
    	
    		System.out.println("Hello world");
    		MovieDao mdao=new MovieDao();
    		Movie movie=new Movie();
//    		movie.setId(21);					//id is auto generated. so we dont supply
//    		movie.setName("Friends");
//    		movie.setReleaseDate(new Date());
    		
//    		mdao.create(movie);
   // 		----------------------------
//		    		movie.setName("Friends");
//		    		movie.setReleaseDate(new Date());
//		    		movie.setId(21);
//		    		mdao.update(movie);
//		    		
//		    		System.out.println("Check db");
    	//	--------------------------------------
    	//	read using id//
//    		System.out.println(mdao.read(21));
    	//	--------------------------only read
    		
//    		List<Movie> movies=mdao.read();
//    		for(Movie m:movies)
//    			System.out.println(m);
    	//	----------------------------
//    		Delete
    		mdao.delete(21);
    	
    }
}
